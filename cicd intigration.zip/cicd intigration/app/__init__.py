"""Example application package."""

__all__ = ["main"]
